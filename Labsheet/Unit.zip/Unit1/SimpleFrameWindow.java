import javax.swing.*;
class SimpleFrameWindow{
    public static void main(String args[]){
        JFrame jf = new JFrame("Santosh Bhandari");
        jf.setSize(500,500);
        jf.setVisible(true);
    }
}